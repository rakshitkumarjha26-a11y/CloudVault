"""
╔══════════════════════════════════════════════════════════════════════╗
║              CloudVault - Mini Google Drive (Cloud Storage App)      ║
║                  Cloud Computing Course Project                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  CLOUD CONCEPTS EXPLAINED:                                           ║
║                                                                      ║
║  ► DEPLOYMENT MODEL: Public Cloud                                    ║
║    This app is designed to be deployed on a public cloud like        ║
║    AWS, Azure, or Google Cloud — accessible over the internet        ║
║    to any registered user, just like Google Drive.                   ║
║                                                                      ║
║  ► SERVICE MODEL: SaaS (Software as a Service)                       ║
║    Users access this storage service via a browser without           ║
║    installing anything. The infrastructure is fully managed.         ║
║                                                                      ║
║  HOW THIS MAPS TO REAL CLOUD PLATFORMS:                              ║
║                                                                      ║
║  LOCAL (This Project)        REAL CLOUD EQUIVALENT                  ║
║  ─────────────────────────   ─────────────────────────────────────  ║
║  Flask app (app.py)      →   AWS EC2 / Azure App Service / GCP Run  ║
║  /uploads/ folder        →   AWS S3 / Azure Blob / GCP Cloud Storage ║
║  MySQL (local)           →   AWS RDS / Azure SQL / GCP Cloud SQL     ║
║  Your laptop             →   Cloud VM (t2.micro, etc.)              ║
║                                                                      ║
║  DEPLOYMENT STEPS (AWS example):                                     ║
║  1. Launch EC2 instance (Ubuntu)                                     ║
║  2. Install Python, Flask, MySQL on EC2                              ║
║  3. Replace /uploads/ with S3 bucket using boto3 library            ║
║  4. Use AWS RDS for MySQL database                                   ║
║  5. Set up Elastic Load Balancer for scalability                     ║
║  6. Use Route 53 for custom domain + SSL certificate                 ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import os
import uuid
from datetime import datetime
from functools import wraps

from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, send_from_directory)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import mysql.connector

# ──────────────────────────────────────────────
#  App Configuration
# ──────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = 'cloudvault-super-secret-key-change-in-production'

# Upload settings
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'doc',
                       'docx', 'txt', 'zip', 'mp4', 'xlsx', 'pptx'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB limit

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ──────────────────────────────────────────────
#  Database Connection
#  In real cloud: replace with AWS RDS endpoint
# ──────────────────────────────────────────────
def get_db():
    """Connect to MySQL. In production, use env variables for credentials."""
    return mysql.connector.connect(
        host='localhost',
        user='root',            # Change to your MySQL username
        password='',            # Change to your MySQL password
        database='cloudvault'
    )


# ──────────────────────────────────────────────
#  Helpers
# ──────────────────────────────────────────────
def allowed_file(filename):
    """Check if file extension is in the allowed list."""
    return ('.' in filename and
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS)


def format_size(size_bytes):
    """Convert bytes to human-readable format."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / (1024**2):.1f} MB"
    return f"{size_bytes / (1024**3):.1f} GB"


def login_required(f):
    """Decorator to protect routes — redirect to login if not logged in."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# ──────────────────────────────────────────────
#  Authentication Routes
# ──────────────────────────────────────────────
@app.route('/')
def index():
    """Landing page — redirect based on login status."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    """User Registration: stores hashed password in MySQL."""
    if request.method == 'POST':
        name     = request.form.get('name', '').strip()
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        # Basic validation
        if not name or not email or not password:
            flash('All fields are required.', 'danger')
            return render_template('register.html')

        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return render_template('register.html')

        # Hash the password — NEVER store plain text passwords!
        hashed_pw = generate_password_hash(password)

        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "INSERT INTO users (name, email, password) VALUES (%s, %s, %s)",
                (name, email, hashed_pw)
            )
            db.commit()
            cursor.close()
            db.close()
            flash('Account created! Please login.', 'success')
            return redirect(url_for('login'))
        except mysql.connector.IntegrityError:
            flash('Email already registered.', 'danger')
        except Exception as e:
            flash(f'Database error: {str(e)}', 'danger')

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """User Login: verify hashed password."""
    if request.method == 'POST':
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        try:
            db = get_db()
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            cursor.close()
            db.close()

            if user and check_password_hash(user['password'], password):
                # Store user info in session (server-side)
                session['user_id']   = user['id']
                session['user_name'] = user['name']
                session['user_email'] = user['email']
                flash(f"Welcome back, {user['name']}!", 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password.', 'danger')
        except Exception as e:
            flash(f'Login error: {str(e)}', 'danger')

    return render_template('login.html')


@app.route('/logout')
def logout():
    """Clear session and redirect to login."""
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


# ──────────────────────────────────────────────
#  Dashboard Route
# ──────────────────────────────────────────────
@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard — shows all files uploaded by the logged-in user."""
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            """SELECT id, original_name, stored_name, file_size, file_type, uploaded_at
               FROM files
               WHERE user_id = %s
               ORDER BY uploaded_at DESC""",
            (session['user_id'],)
        )
        files = cursor.fetchall()
        cursor.close()
        db.close()

        # Add human-readable size and icon info
        for f in files:
            f['size_readable'] = format_size(f['file_size'])
            f['icon'] = get_file_icon(f['file_type'])

        # Compute storage stats
        total_bytes = sum(f['file_size'] for f in files)
        total_size  = format_size(total_bytes)

        return render_template('dashboard.html',
                               files=files,
                               total_files=len(files),
                               total_size=total_size)
    except Exception as e:
        flash(f'Error loading dashboard: {str(e)}', 'danger')
        return render_template('dashboard.html', files=[], total_files=0, total_size='0 B')


# ──────────────────────────────────────────────
#  File Management Routes
# ──────────────────────────────────────────────
@app.route('/upload', methods=['POST'])
@login_required
def upload():
    """
    File Upload Handler.
    Simulates cloud storage upload (like AWS S3 PutObject).
    In production: use boto3.client('s3').upload_file()
    """
    if 'file' not in request.files:
        flash('No file selected.', 'warning')
        return redirect(url_for('dashboard'))

    file = request.files['file']

    if file.filename == '':
        flash('No file selected.', 'warning')
        return redirect(url_for('dashboard'))

    if not allowed_file(file.filename):
        flash(f'File type not allowed. Allowed: {", ".join(ALLOWED_EXTENSIONS)}', 'danger')
        return redirect(url_for('dashboard'))

    try:
        # Create a unique stored filename to avoid collisions
        original_name = secure_filename(file.filename)
        extension     = original_name.rsplit('.', 1)[1].lower()
        stored_name   = f"{uuid.uuid4().hex}.{extension}"
        file_path     = os.path.join(app.config['UPLOAD_FOLDER'], stored_name)

        # Save file to /uploads/ (simulates cloud bucket write)
        file.save(file_path)

        # Get file metadata
        file_size = os.path.getsize(file_path)
        file_type = extension.upper()

        # Save metadata to database
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            """INSERT INTO files (user_id, original_name, stored_name, file_size, file_type)
               VALUES (%s, %s, %s, %s, %s)""",
            (session['user_id'], original_name, stored_name, file_size, file_type)
        )
        db.commit()
        cursor.close()
        db.close()

        flash(f'"{original_name}" uploaded successfully!', 'success')
    except Exception as e:
        flash(f'Upload failed: {str(e)}', 'danger')

    return redirect(url_for('dashboard'))


@app.route('/download/<int:file_id>')
@login_required
def download(file_id):
    """
    File Download Handler.
    Simulates cloud storage download (like AWS S3 GetObject / presigned URL).
    """
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM files WHERE id = %s AND user_id = %s",
            (file_id, session['user_id'])
        )
        file = cursor.fetchone()
        cursor.close()
        db.close()

        if not file:
            flash('File not found or access denied.', 'danger')
            return redirect(url_for('dashboard'))

        return send_from_directory(
            app.config['UPLOAD_FOLDER'],
            file['stored_name'],
            as_attachment=True,
            download_name=file['original_name']
        )
    except Exception as e:
        flash(f'Download failed: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))


@app.route('/delete/<int:file_id>', methods=['POST'])
@login_required
def delete(file_id):
    """
    File Delete Handler.
    Simulates cloud storage deletion (like AWS S3 DeleteObject).
    """
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM files WHERE id = %s AND user_id = %s",
            (file_id, session['user_id'])
        )
        file = cursor.fetchone()

        if not file:
            flash('File not found or access denied.', 'danger')
            cursor.close()
            db.close()
            return redirect(url_for('dashboard'))

        # Delete from disk (simulates S3 DeleteObject)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file['stored_name'])
        if os.path.exists(file_path):
            os.remove(file_path)

        # Remove from database
        cursor.execute("DELETE FROM files WHERE id = %s", (file_id,))
        db.commit()
        cursor.close()
        db.close()

        flash(f'"{file["original_name"]}" deleted successfully.', 'success')
    except Exception as e:
        flash(f'Delete failed: {str(e)}', 'danger')

    return redirect(url_for('dashboard'))


# ──────────────────────────────────────────────
#  Helper: File Type Icons
# ──────────────────────────────────────────────
def get_file_icon(file_type):
    """Return an emoji icon based on file type."""
    icons = {
        'PDF':  '📄', 'DOC': '📝', 'DOCX': '📝',
        'XLS':  '📊', 'XLSX': '📊', 'PPT': '📊', 'PPTX': '📊',
        'PNG':  '🖼️', 'JPG': '🖼️', 'JPEG': '🖼️', 'GIF': '🖼️',
        'ZIP':  '🗜️', 'MP4': '🎬', 'TXT': '📃',
    }
    return icons.get(file_type, '📁')


# ──────────────────────────────────────────────
#  Error Handlers
# ──────────────────────────────────────────────
@app.errorhandler(413)
def file_too_large(e):
    flash('File too large! Maximum size is 10 MB.', 'danger')
    return redirect(url_for('dashboard'))


@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404


# ──────────────────────────────────────────────
#  Run the App
# ──────────────────────────────────────────────
if __name__ == '__main__':
    # debug=True for development only — NEVER in production!
    app.run(debug=True, host='0.0.0.0', port=5000)
