/* CloudVault v2 — main.js */

document.addEventListener('DOMContentLoaded', () => {

  // Auto-dismiss flash messages after 4s
  document.querySelectorAll('.flash').forEach(f => {
    setTimeout(() => {
      f.style.transition = 'opacity .35s ease, transform .35s ease';
      f.style.opacity    = '0';
      f.style.transform  = 'translateX(110%)';
      setTimeout(() => f.remove(), 370);
    }, 4000);
  });

  // Animate file rows in
  document.querySelectorAll('.file-row').forEach((row, i) => {
    row.style.opacity   = '0';
    row.style.transform = 'translateY(6px)';
    row.style.transition = `opacity .22s ease ${i * 0.04}s, transform .22s ease ${i * 0.04}s`;
    requestAnimationFrame(() => {
      row.style.opacity   = '1';
      row.style.transform = 'translateY(0)';
    });
  });

  // File input & drag-drop
  const fileInput   = document.getElementById('file-input');
  const dropZone    = document.getElementById('drop-zone');
  const dropInner   = document.getElementById('drop-inner');
  const selFile     = document.getElementById('selected-file');
  const selName     = document.getElementById('sel-name');
  const selSize     = document.getElementById('sel-size');
  const btnUpload   = document.getElementById('btn-upload');
  const progWrap    = document.getElementById('progress-wrap');
  const progFill    = document.getElementById('prog-fill');
  const progPct     = document.getElementById('prog-pct');
  const progName    = document.getElementById('prog-name');

  function fmtBytes(b) {
    if (b < 1024)        return b + ' B';
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
    return (b / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function showPreview(file) {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      alert(`"${file.name}" is too large (${fmtBytes(file.size)}). Max is 10 MB.`);
      fileInput.value = '';
      return;
    }
    selName.textContent = file.name;
    selSize.textContent = fmtBytes(file.size);
    if (dropInner) dropInner.style.display = 'none';
    selFile.style.display = 'flex';
    btnUpload.disabled = false;
  }

  if (fileInput) {
    fileInput.addEventListener('change', () => {
      if (fileInput.files[0]) showPreview(fileInput.files[0]);
    });
  }

  if (dropZone) {
    dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
    dropZone.addEventListener('drop', e => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
      const f = e.dataTransfer.files[0];
      if (f) {
        const dt = new DataTransfer();
        dt.items.add(f);
        fileInput.files = dt.files;
        showPreview(f);
      }
    });
  }

  // Upload form — show progress bar
  const uploadForm = document.getElementById('upload-form');
  if (uploadForm) {
    uploadForm.addEventListener('submit', () => {
      if (btnUpload && !btnUpload.disabled) {
        const name = selName ? selName.textContent : 'file';
        if (progName) progName.textContent = 'Uploading ' + name + '…';
        if (progWrap)  progWrap.style.display = 'block';
        if (progFill)  progFill.style.width   = '0%';

        // Animate progress bar while server processes
        let p = 0;
        const iv = setInterval(() => {
          p += Math.random() * 18 + 6;
          if (p >= 90) { p = 90; clearInterval(iv); }
          if (progFill) progFill.style.width = p + '%';
          if (progPct)  progPct.textContent  = Math.round(p) + '%';
        }, 120);

        btnUpload.disabled  = true;
        btnUpload.textContent = 'Uploading…';
      }
    });
  }

});

// Upload panel toggle
function toggleUpload() {
  const panel = document.getElementById('upload-panel');
  if (panel) panel.classList.toggle('open');
}

function closeUpload() {
  const panel = document.getElementById('upload-panel');
  if (panel) panel.classList.remove('open');
}

// Delete confirmation
function confirmDelete(name) {
  return confirm(`Delete "${name}"?\n\nThis cannot be undone.`);
}
