/**
 * CloudVault — main.js
 * Handles: drag-and-drop, file selection preview,
 *          delete confirmation, auto-dismiss flashes.
 */

document.addEventListener('DOMContentLoaded', () => {

    // ──────────────────────────────────────────────
    //  Flash Message Auto-Dismiss (after 4 seconds)
    // ──────────────────────────────────────────────
    const flashes = document.querySelectorAll('.flash');
    flashes.forEach(flash => {
        setTimeout(() => {
            flash.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            flash.style.opacity    = '0';
            flash.style.transform  = 'translateX(120%)';
            setTimeout(() => flash.remove(), 400);
        }, 4000);
    });


    // ──────────────────────────────────────────────
    //  File Upload: Preview & Drag-and-Drop
    // ──────────────────────────────────────────────
    const fileInput    = document.getElementById('file-input');
    const dropZone     = document.getElementById('drop-zone');
    const selectedFile = document.getElementById('selected-file');
    const selectedName = document.getElementById('selected-name');
    const selectedSize = document.getElementById('selected-size');
    const btnUpload    = document.getElementById('btn-upload');
    const dropContent  = dropZone?.querySelector('.drop-zone-content');

    // Format bytes to readable string
    function formatBytes(bytes) {
        if (bytes < 1024)        return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    // Show selected file info
    function showFilePreview(file) {
        if (!file) return;

        const maxSize = 10 * 1024 * 1024; // 10 MB

        if (file.size > maxSize) {
            alert(`File too large: ${formatBytes(file.size)}\nMaximum allowed: 10 MB`);
            fileInput.value = '';
            return;
        }

        selectedName.textContent = file.name;
        selectedSize.textContent = formatBytes(file.size);

        if (dropContent)  dropContent.style.display  = 'none';
        selectedFile.style.display = 'flex';
        btnUpload.disabled = false;
    }

    // File input change
    if (fileInput) {
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                showFilePreview(fileInput.files[0]);
            }
        });
    }

    // Drag-and-drop events
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');

            const files = e.dataTransfer.files;
            if (files.length > 0) {
                // Transfer dropped file to the actual input
                const dt = new DataTransfer();
                dt.items.add(files[0]);
                fileInput.files = dt.files;
                showFilePreview(files[0]);
            }
        });
    }


    // ──────────────────────────────────────────────
    //  Upload progress indicator (simulated)
    // ──────────────────────────────────────────────
    const uploadForm = document.getElementById('upload-form');
    if (uploadForm) {
        uploadForm.addEventListener('submit', () => {
            if (btnUpload) {
                btnUpload.textContent = 'Uploading…';
                btnUpload.disabled    = true;
            }
        });
    }


    // ──────────────────────────────────────────────
    //  Animate file rows on page load
    // ──────────────────────────────────────────────
    const fileRows = document.querySelectorAll('.file-row');
    fileRows.forEach((row, i) => {
        row.style.opacity   = '0';
        row.style.transform = 'translateY(8px)';
        row.style.transition = `opacity 0.25s ease ${i * 0.04}s, transform 0.25s ease ${i * 0.04}s`;
        requestAnimationFrame(() => {
            row.style.opacity   = '1';
            row.style.transform = 'translateY(0)';
        });
    });

});


// ──────────────────────────────────────────────
//  Delete confirmation (called from template)
// ──────────────────────────────────────────────
function confirmDelete(filename) {
    return confirm(`Delete "${filename}"?\n\nThis action cannot be undone.`);
}
